<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
$(document).ready(function(){
    $("button").click(function(){
        $("h2").hide();
    })
})